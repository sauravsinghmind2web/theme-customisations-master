<?php
/**
 * Functions.php
 *
 * @package  Theme_Customisations
 * @author   WooThemes
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * functions.php
 * Add PHP snippets here
 */
// Custom one-time password set email content
function custom_one_time_password_email( $message, $user_id, $plaintext_pass ) {
    error_log('Custom one-time password email function called.'); // Add log message

    $user_data = get_userdata( $user_id );
    if ( ! $user_data ) {
        return $message;
    }

    $user_login = $user_data->user_login;

    // Generate the password set URL with a unique nonce parameter
    $password_set_url = wp_nonce_url(
        site_url( "https://app.adnosaur.com?action=rp&key=" . $plaintext_pass . "&login=" . rawurlencode( $user_login ) ),
        'reset-password'
    );

    // Customize your email template below
    $subject = 'Welcome to Adnosaur';
    $email_template = "
        <html>
        <head>
            <title>$subject</title>
        </head>
        <body>
            <h2>Hello,</h2>
            <p>An account has been created for you on adnosaur.com.</p>
            <p>To set your password and access your account, click on the following link:</p>
            <a href='$password_set_url'>$password_set_url</a>
            <p>If you did not create an account, please ignore this email.</p>
            <p>Regards,</p>
            <p>Your Adnosaur Team</p>
        </body>
        </html>
    ";

    // Set the email content
    $message['subject'] = $subject;
    $message['message'] = $email_template;

    return $message;
}
add_filter( 'wpmu_signup_user_notification_email', 'custom_one_time_password_email', 10, 3 );
add_filter( 'wp_new_user_notification_email', 'custom_one_time_password_email', 10, 3 );

// Redirect one-time password set link to ReactJS site
function redirect_one_time_password_set() {
    error_log('Redirect one-time password set function called.'); // Add log message

    if ( isset( $_GET['action'] ) && $_GET['action'] === 'rp' ) {
        $reset_key = $_GET['key'];
        $user_login = $_GET['login'];

        // Replace 'https://your-reactjs-site.com/set-password' with the actual URL of your ReactJS password set page
        $set_password_page_url = 'https://app.adnosaur.com/set-password?user_login=' . rawurlencode( $user_login ) . '&key=' . rawurlencode( $reset_key );

        wp_redirect( $set_password_page_url );
        exit;
    }
}
add_action( 'init', 'redirect_one_time_password_set' );





